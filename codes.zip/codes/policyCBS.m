function f=policyCBS(p,c,h,n1,m1,Leadtime,demand)
dmd=unique(demand)*(Leadtime+1);
n0=length(dmd);
n2=n0*(n0-1)/2;
rS=zeros(n2,2);j=1;
for j1=1:(n0-1)
    for j2=(j1+1):n0
        rS(j,1)=dmd(j1);rS(j,2)=dmd(j2);
        j=j+1;
    end
end
OrderQ=zeros(Leadtime+n1,n2);result=zeros(n2,1);
for j2=1:n2
    OrderQ(1:Leadtime,j2)=m1;OrderQ(Leadtime+1:Leadtime+n1,j2)=0;profit=zeros(n1,1);cost=zeros(n1,1);
    ArrivalQ=zeros(n1,1);CarryQ=zeros(n1,1);InitialQ=zeros(n1,1);Sales=zeros(n1,1);ClosingQ=zeros(n1,1);
    for j1=1:n1
        ArrivalQ(j1,1)=OrderQ(j1,j2);
        if j1==1
            CarryQ(j1)=0;
        else
            CarryQ(j1)=ClosingQ(j1-1);
        end
        InitialQ(j1)=ArrivalQ(j1)+CarryQ(j1);
        if Leadtime==1
            sum_q=0;
        else
            sum_q=sum(OrderQ(j1+1:j1+Leadtime-1,j2));
        end
        OrderQ(Leadtime+j1,j2)=min(rS(j2,1),max(0,rS(j2,2)-InitialQ(j1)-sum_q));
        Sales(j1)=min(InitialQ(j1),demand(j1));
        ClosingQ(j1)=InitialQ(j1)-Sales(j1);
        profit(j1)=p*Sales(j1)-c*OrderQ(Leadtime+j1,j2)-h*ClosingQ(j1);
        cost(j1)=h*ClosingQ(j1)+p*max(0,demand(j1)-InitialQ(j1));
    end
    result(j2)=mean(profit);
end
mx=max(result);
position=find(result==mx);
f=[mx;std(OrderQ(Leadtime+1:Leadtime+n1,position(1)))];
return