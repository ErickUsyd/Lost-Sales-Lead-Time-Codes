function f=policyFP3f(leadtime,simu_path_cal,simu_demand,targetP)
if max(simu_path_cal)==0
    L=round(max(1,min(simu_demand)));
    H=round(max(simu_demand))*(leadtime+1);
else
    L=round(max(1,min(simu_path_cal)));
    H=round(max(simu_path_cal))*(leadtime+1);
end
Qt=transpose(linspace(L,H,H-L+1));
Stockout=Qt+simu_path_cal-simu_demand;
Stockout(Stockout>=0)=1;
Stockout(Stockout<0)=0;
prob=mean(Stockout,2);
[~,idx]=min(abs(prob-targetP));
f=Qt(idx(1));
return