%%policy comparison --- industry data
clc
clear
clear vars
tic;
data=readmatrix('DataSKU.xlsx','Sheet','Sheet1');
n_sku=size(data,2);
Ldt=[6,7,8,9,10];%%Leadtime
n_Ldt=length(Ldt);
price=15:5:200;%%setting the prices
n_price=length(price);
c=0;h=1;
demandtype=1;%normal distribution for 1 and gamma distribution for 2
n_simu=100000;%the length of simulated demand
nn=7;
result_pft=zeros(nn*n_Ldt*n_price,n_sku);
options=optimset('MaxFunEvals',100000,'MaxIter',100000);
flag_PIL=1;flag_FP3=1;flag_Robust=1;flag_MAD=1;flag_WAP=1;flag_CBSN=1;flag_CBS=1;
training=0;
for j0=1:n_sku
    demand_data=data(:,j0);
    demand_data(isnan(demand_data))=[];
    if training==0
        demand_training=demand_data;demand_testing=demand_data;
    else
        demand_training=demand_data(1:training);demand_testing=demand_data(training+1:end);
    end
    n_training=length(demand_training);n_testing=length(demand_testing);
    m_training=mean(demand_training);m_testing=mean(demand_testing);
    s_training=std(demand_training);
    if demandtype==1
        simu_d=normrnd(m_training,s_training,1,n_simu);
    elseif demandtype==2
        b_gama=m_training/s_training/s_training;%gamma distribution
        a_gama=b_gama*m_training;
        simu_d=gamrnd(a_gama,1/b_gama,1,n_simu);
    end
    if demandtype==1
        data_simu=transpose(normrnd(m_training,s_training,1,n_simu));%generate a Normal distribution with n_simu points
    elseif demandtype==2
        data_simu=transpose(gamrnd(a_gama,1/b_gama,1,n_simu));%generate a gamma distribution with n_simu points
    end
    if flag_MAD==1
        d=mad(demand_training);L=min(demand_training);H=max(demand_training);
        pr1=d/(2*(m_training-L));pr2=1-d/(2*(m_training-L))-d/(2*(H-m_training));pr3=d/(2*(H-m_training));
        pr12=pr1+pr2;
        MADdemand=zeros(n_training,1);
        demand=rand(n_training,1);
        for j1=1:n_training
            if demand(j1)<=pr1
                MADdemand(j1)=L;
            elseif pr1<demand(j1) && demand(j1)<=pr12
                MADdemand(j1)=m_training;
            elseif pr12<=demand(j1)
                MADdemand(j1)=H;
            end
        end
    end
    for j1=1:n_Ldt
        Leadtime=Ldt(j1);
        %disp(['demand=' num2str(j0) '/' num2str(n_sku) ', Leadtime=' num2str(j1) '/' num2str(n_Ldt)]);
        s_Lt=sqrt(Leadtime+1)*s_training;
        m_Lt=m_training*(Leadtime+1);
        if demandtype==1
            simu_path=normrnd(m_training,s_training,Leadtime,n_simu);
        elseif demandtype==2
            simu_path=gamrnd(a_gama,1/b_gama,Leadtime,n_simu);
            b_gamma=m_Lt/s_Lt/s_Lt;%gamma distribution
            a_gamma=b_gamma*m_Lt;
        end
        for j2=1:n_price
            pft_PIL=0;pft_FP3=0;pft_Robust=0;pft_MAD=0;pft_WAP=0;pft_CBSN=0;pft_CBS=0;
            std_PIL=0;std_FP3=0;std_Robust=0;std_MAD=0;std_WAP=0;std_CBSN=0;std_CBS=0;
            p=price(j2);
            disp(['demand=' num2str(j0) '/' num2str(n_sku) ', Leadtime=' num2str(j1) '/' num2str(n_Ldt) ', price=' num2str(j2) '/' num2str(n_price)]);
            ratio=(p-c)/(p-c+h);
            if demandtype==1
                Q_target=norminv((p-c)/(p-c+h),m_training,s_training);
            elseif demandtype==2
                Q_target=gaminv((p-c)/(p-c+h),a_gama,1/b_gama);
            end
            if flag_PIL==1
                fval=policyPILindustryB(Q_target,p,c,h,n_testing,m_training,Leadtime,demand_testing,simu_path);
                pft_PIL=fval(1);
            end
            %%%%%%%%%---end of PIL
            if flag_Robust==1
                Q_robust=(Leadtime+1)*m_training+0.5*s_training*(sqrt((p-c)/h)-(Leadtime+1)*sqrt(h/(p-c)));
                fval=policyRobust(Q_robust,p,c,h,n_testing,m_training,Leadtime,demand_testing);
                pft_Robust=fval(1);
            end
            %%%%%%%%%---end of robust
            if flag_WAP==1
                if demandtype==1
                    Q_wap=ratio*norminv(ratio,m_Lt,s_Lt)+(1-ratio)*norminv(ratio,m_training,s_training);%normal distribution --- weighted average (stationary base-stock level)
                elseif demandtype==2
                    Q_wap=ratio*gaminv(ratio,a_gamma,1/b_gamma)+(1-ratio)*gaminv(ratio,a_gama,1/b_gama);%gamma distribution
                end
                fval=policyWAP(Q_wap,p,c,h,n_testing,m_training,Leadtime,demand_testing);
                pft_WAP=fval(1);
            end
            %%%%%%%%%---end of WAP
            if flag_MAD==1
                Q=m_training;%
                fval=policyMAD(Q,p,c,h,n_testing,m_training,Leadtime,demand_testing,MADdemand,options);
                pft_MAD=fval(1);
            end
            %%%%%%%%%---end of MAD
            if flag_FP3==1
                fval=policyFP3industry(p,c,h,n_training,n_testing,m_training,m_testing,Leadtime,demand_training,demand_testing,simu_path,simu_d,n_simu,options);
                pft_FP3=fval(1);
            end
            %%%%%%%%%---end of FP3
            if flag_CBS==1
                fval=policyCBSsearch(p,c,h,n_testing,m_testing,Leadtime,demand_testing,options);
                pft_CBS=fval(1);
            end
            %%%%%%%%---end of CBS
            if flag_CBSN==1
                fval=policyCBSNsearch(p,c,h,n_training,n_testing,m_training,m_testing,Leadtime,data_simu,demand_testing,options);
                pft_CBSN=fval(1);
            end
            %%%%%%%%---end of CBS with simulated normal distribution
            result_pft(nn*((j1-1)*n_price+j2-1)+1:nn*((j1-1)*n_price+j2),j0)=[pft_Robust;pft_WAP;pft_MAD;pft_PIL;pft_FP3;pft_CBSN;pft_CBS];
        end
    end
end
result_sum=SumCalculation(result_pft,n_sku,n_Ldt,n_price,nn);
toc;
return