function f=policyFP3(p,c,h,n1,m,Leadtime,demand,targetP,simu_path,simu_d)
OrderQ(1:Leadtime)=m;OrderQ(Leadtime+1:Leadtime+n1)=0;OrderQ=transpose(OrderQ);
ArrivalQ=zeros(n1,1);CarryQ=zeros(n1,1);InitialQ=zeros(n1,1);Sales=zeros(n1,1);ClosingQ=zeros(n1,1);profit=zeros(n1,1);cost=zeros(n1,1);
for j=1:n1
    ArrivalQ(j,1)=OrderQ(j);
    if j==1
        CarryQ(j)=0;
    else
        CarryQ(j)=ClosingQ(j-1);
    end
    InitialQ(j)=ArrivalQ(j)+CarryQ(j);
    if Leadtime==1
        simu_Q=InitialQ(j);
    elseif Leadtime>=2
        simu_Q(1,1)=InitialQ(j);
        simu_Q(2:Leadtime,1)=OrderQ(j+1:j+Leadtime-1,1);
    end
    path_q=0;
    for j1=1:Leadtime
        path_q=max(0,path_q+simu_Q(j1)-simu_path(j1,:));
    end
    x0=policyFP3f(Leadtime,path_q,simu_d,targetP);
    OrderQ(Leadtime+j)=x0; 
    Sales(j)=min(InitialQ(j),demand(j));
    ClosingQ(j)=InitialQ(j)-Sales(j);
    profit(j)=p*Sales(j)-c*OrderQ(Leadtime+j)-h*ClosingQ(j);
    cost(j)=h*ClosingQ(j)+p*max(0,demand(j)-InitialQ(j));
end
f=[mean(profit);std(OrderQ(Leadtime+1:Leadtime+n1))];
return