function f=policyFP3industryf(x,p,c,h,n_training,m_training,Leadtime,demand_training,simu_path,simu_d,n_simu,options)
OrderQ(1:Leadtime)=m_training;
OrderQ(Leadtime+1:Leadtime+n_training)=0;OrderQ=transpose(OrderQ);
ArrivalQ=zeros(n_training,1);CarryQ=zeros(n_training,1);InitialQ=zeros(n_training,1);Sales=zeros(n_training,1);ClosingQ=zeros(n_training,1);profit=zeros(n_training,1);cost=zeros(n_training,1);
for j=1:n_training
    ArrivalQ(j,1)=OrderQ(j);
    if j==1
        CarryQ(j)=0;
    else
        CarryQ(j)=ClosingQ(j-1);
    end
    InitialQ(j)=ArrivalQ(j)+CarryQ(j);
    if Leadtime==1
        simu_Q=InitialQ(j);
    elseif Leadtime>=2
        simu_Q(1,1)=InitialQ(j);
        simu_Q(2:Leadtime,1)=OrderQ(j+1:j+Leadtime-1,1);
    end
    path_q=0;
    for j1=1:Leadtime
        path_q=max(0,path_q+simu_Q(j1)-max(0,simu_path(j1,:)));
    end
    [x0(1),fval0(1)]=fminsearch(@(xx) policyFP3induf(xx,path_q,simu_d,n_simu,x),m_training,options);
    [x0(2),fval0(2)]=fminsearch(@(xx) policyFP3induf(xx,path_q,simu_d,n_simu,x),Leadtime*m_training,options);
    x1=x0(fval0==min(fval0));
    OrderQ(Leadtime+j)=x1(1);
    Sales(j)=min(InitialQ(j),demand_training(j));
    ClosingQ(j)=InitialQ(j)-Sales(j);
    profit(j)=p*Sales(j)-c*OrderQ(Leadtime+j)-h*ClosingQ(j);
    cost(j)=h*ClosingQ(j)+p*max(0,demand_training(j)-InitialQ(j));
end
f=(-1)*mean(profit);
return