function f=SumCalculation(data1,n0,n1,n2,nn)
result_pft=data1;
best_p=zeros((nn-1)*n1*n2,n0);
best_c=zeros((nn-1)*n1*n2,n0);
for j=1:n1*n2
    mx=max(result_pft(nn*(j-1)+1:nn*(j-1)+(nn-1),:));
    best_p((nn-1)*(j-1)+1:(nn-1)*j,:)=(result_pft(nn*(j-1)+1:nn*(j-1)+(nn-1),:)==mx);
    best_c((nn-1)*(j-1)+1:(nn-1)*j,:)=1-result_pft(nn*(j-1)+1:nn*(j-1)+(nn-1),:)./result_pft(nn*j,:);
end
sm_p=sum(best_p,2);sm_c=sum(best_c,2);
sm_p1=zeros((nn-1)*n2,1);sm_c1=zeros((nn-1)*n2,1);
for j=1:n1
    sm_p1(:,j)=sm_p((nn-1)*(j-1)*n2+1:(nn-1)*j*n2,1);
    sm_c1(:,j)=sm_c((nn-1)*(j-1)*n2+1:(nn-1)*j*n2,1);
end
sm_p2=zeros((nn-1),n1);sm_c2=zeros((nn-1),n1);
for j1=1:n1
    for j2=1:n2
        sm_p2(1:(nn-1),j1)=sm_p2(1:(nn-1),j1)+sm_p1((nn-1)*(j2-1)+1:(nn-1)*j2,j1);
        sm_c2(1:(nn-1),j1)=sm_c2(1:(nn-1),j1)+sm_c1((nn-1)*(j2-1)+1:(nn-1)*j2,j1);
    end
end
best_pm=zeros((nn-2)*n1*n2,n0);
for j=1:n1*n2
    mx=max(result_pft(nn*(j-1)+2:nn*(j-1)+(nn-1),:));
    best_pm((nn-2)*(j-1)+1:(nn-2)*j,:)=(result_pft(nn*(j-1)+2:nn*(j-1)+(nn-1),:)==mx);
end
sm_c2=sm_c2/n0/n2;
pft1=sum(result_pft,2);
pft2=zeros(nn,n1);
for j1=1:n1
    for j2=1:n2
        pft2(1:nn,j1)=pft2(1:nn,j1)+pft1(nn*n2*(j1-1)+nn*(j2-1)+1:nn*n2*(j1-1)+nn*j2,1);
    end
end
pft2=pft2/n0/n2;
f=[sm_c2;pft2];
return