function f=policyCBSNsearch(p,c,h,n1,n2,m1,m2,Leadtime,demand_simu,demand_testing,options)
[x,~]=fminsearch(@(x) policyCBSsearchf(x,p,c,h,n1,m1,Leadtime,demand_simu),[m1,(Leadtime+1)*m1],options);
OrderQ(1:Leadtime,1)=m2;
OrderQ(Leadtime+1:Leadtime+n2,1)=0;profit=zeros(n2,1);cost=zeros(n2,1);
ArrivalQ=zeros(n2,1);CarryQ=zeros(n2,1);InitialQ=zeros(n2,1);Sales=zeros(n2,1);ClosingQ=zeros(n2,1);
for j1=1:n2
    ArrivalQ(j1,1)=OrderQ(j1,1);
    if j1==1
        CarryQ(j1)=0;
    else
        CarryQ(j1)=ClosingQ(j1-1);
    end
    InitialQ(j1)=ArrivalQ(j1)+CarryQ(j1);
    if Leadtime==1
        sum_q=0;
    else
        sum_q=sum(OrderQ(j1+1:j1+Leadtime-1,1));
    end
    OrderQ(Leadtime+j1,1)=min(x(1),max(0,x(2)-InitialQ(j1)-sum_q));
    Sales(j1)=min(InitialQ(j1),demand_testing(j1));
    ClosingQ(j1)=InitialQ(j1)-Sales(j1);
    profit(j1)=p*Sales(j1)-c*OrderQ(Leadtime+j1,1)-h*ClosingQ(j1);
    cost(j1)=h*ClosingQ(j1)+p*max(0,demand_testing(j1)-InitialQ(j1));
end
f=[mean(profit);std(OrderQ(Leadtime+1:Leadtime+n2))];
return