function f=policyPILindustryB(targetQ,p,c,h,n_testing,m_training,Leadtime,demand_testing,simu_path)
OrderQ=zeros(Leadtime+n_testing,1);OrderQ(1:Leadtime,1)=m_training;
OrderQ(Leadtime+1:Leadtime+n_testing,1)=0;profit=zeros(n_testing,1);cost=zeros(n_testing,1);
ArrivalQ=zeros(n_testing,1);CarryQ=zeros(n_testing,1);InitialQ=zeros(n_testing,1);Sales=zeros(n_testing,1);ClosingQ=zeros(n_testing,1);
for j1=1:n_testing
    ArrivalQ(j1,1)=OrderQ(j1,1);
    if j1==1
        CarryQ(j1)=0;
    else
        CarryQ(j1)=ClosingQ(j1-1);
    end
    InitialQ(j1)=ArrivalQ(j1)+CarryQ(j1);
    if Leadtime==1
        simu_Q=InitialQ(j1);
    elseif Leadtime>=2
        simu_Q(1,1)=InitialQ(j1);
        simu_Q(2:Leadtime,1)=OrderQ(j1+1:j1+Leadtime-1,1);
    end
    path_q=0;
    for j0=1:Leadtime
        path_q=max(0,path_q+simu_Q(j0)-simu_path(j0,:));
    end
    OrderQ(Leadtime+j1,1)=targetQ-mean(path_q);
    Sales(j1)=min(InitialQ(j1),demand_testing(j1));
    ClosingQ(j1)=InitialQ(j1)-Sales(j1);
    profit(j1)=p*Sales(j1)-c*OrderQ(Leadtime+j1,1)-h*ClosingQ(j1);
    cost(j1)=h*ClosingQ(j1)+p*max(0,demand_testing(j1)-InitialQ(j1));
end
result=mean(profit);
f=[result;std(OrderQ(Leadtime+1:Leadtime+n_testing))];
return