function f=policyFP3induf(x,simu_path_cal,simu_demand,n_simu,targetP)
Stockout=x+simu_path_cal-simu_demand;
Stockout(Stockout>=0)=1;
Stockout(Stockout<0)=0;
positivecases=sum(Stockout);
f=abs(n_simu*targetP-positivecases);
return