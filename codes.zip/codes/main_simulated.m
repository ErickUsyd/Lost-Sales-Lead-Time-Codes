%%policy comparison --- simulated data
clc
clear
clear vars
tic;
demandtype=1;%determine which demand type to use, 1 is for poisson, 2 is for geometric
m=5;%choosing the mean of demand distribution
s=sqrt(m);
n1=1000;n2=100;%determining the data size n1*n2
if demandtype==1
    data=poissrnd(m,n1,n2);
elseif demandtype==2
    data=geornd(1/m,n1,n2)+1;
end
demand=data(:);
n1=length(demand);
n2=100000;%the length of simulated demand
u1=mean(demand);s1=sqrt(u1);
price=[19,19,19,19];%%setting the prices
L_price=length(price);
Ldt=[1,2,3,4];%setting the leadtime
L_Ldt=length(Ldt);
c=0;h=1;
result=zeros(L_price*L_Ldt,5);
p_PIL=1;p_FP3=1;p_Robust=1;p_CBS=1;p_BST=1;
for j=1:L_Ldt
    Leadtime=Ldt(j);
    if demandtype==1
        simu_path=poissrnd(u1,Leadtime,n2);
        simu_d=poissrnd(u1,1,n2);
    elseif demandtype==2
        simu_path=geornd(1/u1,Leadtime,n2)+1;
        simu_d=geornd(1/u1,1,n2)+1;
    end
    for j1=1:L_price
        pft_PIL=0;pft_FP3=0;pft_Robust=0;pft_CBS=0;pft_BST=0;
        disp(['j=' num2str(j) '/' num2str(L_Ldt) ',j1=' num2str(j1) '/' num2str(L_price)]);
        p=price(j,j1);
        if demandtype==1
            targetQ=poissinv((p-c)/(p+h),u1);
        elseif demandtype==2
            targetQ=geoinv((p-c)/(p+h),1/u1)+1;
        end
        if p_PIL==1
            tartQ=[targetQ-1,targetQ,targetQ+1,targetQ+2];
            pft_PIL=policyPIL(p,c,h,n1,u1,Leadtime,demand,tartQ,simu_path);
            pft_PIL=pft_PIL(1);
        end
        if p_Robust==1
            RobustQ=(Leadtime+1)*u1+0.5*s1*(sqrt((p-c)/h)-(Leadtime+1)*sqrt(h/(p-c)));
            pft_Robust=policyRobust(RobustQ,p,c,h,n1,u1,Leadtime,demand);
            pft_Robust=pft_Robust(1);
        end
        targetP=(p-c)/(p+h);
        if p_FP3==1
            pft_FP3=policyFP3(p,c,h,n1,u1,Leadtime,demand,targetP,simu_path,simu_d);
            pft_FP3=pft_FP3(1);
        end
        if p_CBS==1
            pft_CBS=policyCBS(p,c,h,n1,u1,Leadtime,demand);
            pft_CBS=pft_CBS(1);
        end
        if p_BST==1
            pft_BST=policyBST(p,c,h,n1,u1,Leadtime,demand);
            pft_BST=pft_BST(1);
        end
        result((j-1)*L_price+j1,:)=[pft_PIL,pft_FP3,pft_CBS,pft_Robust,pft_BST];
    end
end
toc;
return