function f=policyMAD(Q,p,c,h,n,m1,Leadtime,demand,MADdemand,options)%the demand has been revised before running NwMADf
nn=length(Q);
xx=zeros(nn,1);fval=zeros(nn,1);
for j=1:nn
    [xx(j,:),fval(j)]=fminsearch(@(x) policyMADf(x,p,c,h,m1,Leadtime,MADdemand),Q(j),options);
end
x0=xx(fval==min(fval),:);
x0(2:end,:)=[];
OrderQ(1:Leadtime)=m1;
OrderQ(Leadtime+1:Leadtime+n)=0;OrderQ=transpose(OrderQ);
ArrivalQ=zeros(n,1);CarryQ=zeros(n,1);InitialQ=zeros(n,1);Sales=zeros(n,1);ClosingQ=zeros(n,1);profit=zeros(n,1);cost=zeros(n,1);
for j=1:n
    ArrivalQ(j,1)=OrderQ(j);
    if j==1
        CarryQ(j)=0;
    else
        CarryQ(j)=ClosingQ(j-1);
    end
    InitialQ(j)=ArrivalQ(j)+CarryQ(j);
    if Leadtime==1
        sum_q=0;
    else
        sum_q=sum(OrderQ(j+1:j+Leadtime-1,1));
    end
    OrderQ(Leadtime+j)=max(0,x0-InitialQ(j)-sum_q);
    Sales(j)=min(InitialQ(j),demand(j));
    ClosingQ(j)=InitialQ(j)-Sales(j);
    profit(j)=p*Sales(j)-c*OrderQ(Leadtime+j)-h*ClosingQ(j);
    cost(j)=h*ClosingQ(j)+p*max(0,demand(j)-InitialQ(j));
end
f=[mean(profit);std(OrderQ(Leadtime+1:Leadtime+n))];
return