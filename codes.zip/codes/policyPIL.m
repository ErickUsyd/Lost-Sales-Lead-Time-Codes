function f=policyPIL(p,c,h,n1,m1,Leadtime,demand,targetQ,simu_path)
n2=length(targetQ);
OrderQ=zeros(Leadtime+n1,n2);result=zeros(n2,1);
for j2=1:n2
    OrderQ(1:Leadtime,j2)=m1;OrderQ(Leadtime+1:Leadtime+n1,j2)=0;profit=zeros(n1,1);cost=zeros(n1,1);
    ArrivalQ=zeros(n1,1);CarryQ=zeros(n1,1);InitialQ=zeros(n1,1);Sales=zeros(n1,1);ClosingQ=zeros(n1,1);
    for j1=1:n1
        ArrivalQ(j1,1)=OrderQ(j1,j2);
        if j1==1
            CarryQ(j1)=0;
        else
            CarryQ(j1)=ClosingQ(j1-1);
        end
        InitialQ(j1)=ArrivalQ(j1)+CarryQ(j1);
        if Leadtime==1
            simu_Q=InitialQ(j1);
        elseif Leadtime>=2
            simu_Q(1,1)=InitialQ(j1);
            simu_Q(2:Leadtime,1)=OrderQ(j1+1:j1+Leadtime-1,j2);
        end
        path_q=0;
        for j0=1:Leadtime
            path_q=max(0,path_q+simu_Q(j0)-simu_path(j0,:));
        end
        OrderQ(Leadtime+j1,j2)=targetQ(j2)-mean(path_q);
        Sales(j1)=min(InitialQ(j1),demand(j1));
        ClosingQ(j1)=InitialQ(j1)-Sales(j1);
        profit(j1)=p*Sales(j1)-c*OrderQ(Leadtime+j1,j2)-h*ClosingQ(j1);
        cost(j1)=h*ClosingQ(j1)+p*max(0,demand(j1)-InitialQ(j1));
    end
    result(j2)=mean(profit);
end
mx=max(result);
position=find(result==mx);
f=[mx;std(OrderQ(Leadtime+1:Leadtime+n1,position(1)))];
return